<?php

// Define some constants
define( "RECIPIENT_NAME", "GIVE CLEAN ADMIN" );
define( "RECIPIENT_EMAIL", "robertbfarris@gmail.com" );


// Read the form values
$success = false;
$name = isset( $_POST['username'] ) ? preg_replace( "/[^\.\-\' a-zA-Z0-9]/", "", $_POST['name'] ) : "";
$company = isset( $_POST['company'] ) ? preg_replace( "/[^\.\-\' a-zA-Z0-9]/", "", $_POST['company'] ) : "";
$mailFrom = isset( $_POST['email'] ) ? preg_replace( "/[^\.\-\' a-zA-Z0-9]/", "", $_POST['mailFrom'] ) : "";
$phone = isset( $_POST['phone'] ) ? preg_replace( "/[^\.\-\' a-zA-Z0-9]/", "", $_POST['phone'] ) : "";
$address = isset( $_POST['address'] ) ? preg_replace( "/[^\.\-\' a-zA-Z0-9]/", "", $_POST['address'] ) : "";
$squarefeet = isset( $_POST['squarefeet'] ) ? preg_replace( "/[^\.\-\' a-zA-Z0-9]/", "", $_POST['squarefeet'] ) : "";
$cleaningtype = isset( $_POST['squarefeet'] ) ? preg_replace( "/[^\.\-\' a-zA-Z0-9]/", "", $_POST['cleaningtype'] ) : "";

$message = isset( $_POST['message'] ) ? preg_replace( "/(From:|To:|BCC:|CC:|Message:|Content-Type:)/", "", $_POST['message'] ) : "";

// If all values exist, send the email
if ( $name && $mailFrom && $message) {
  $recipient = RECIPIENT_NAME . " <" . RECIPIENT_EMAIL . ">";
  $headers = "From: " . $name . " <" . $mailFrom . ">";
  $msgBody = "Message: " . $message . "";
  $success = mail( $recipient, $headers, $msgBody );

  //Set Location After Successsfull Submission
  header('Location: contact.html?message=Successfull');
}

else{
	//Set Location After Unsuccesssfull Submission
  	header('Location: index.html?message=Failed');	
}

?>