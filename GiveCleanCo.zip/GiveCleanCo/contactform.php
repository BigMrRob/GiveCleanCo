<?php

if(isset($_POST['submit'])) {
    $name = $_POST['name'];
    $company = $_POST['company'];
    $mailFrom = $_POST['email'];
    $phone = $_POST['phone'];
    $address = $_POST['address'];
    $squarefeet = $_POST['squarefeet'];
    $cleaningtype = $_POST['cleaningtype'];
    $message = $_POST['message'];

    $mailTo = "robertbfarris@gmail.com";
    $headers = "From: ".$mailFrom;
    $txt = "Name: ".$name."\n
            Company: ".$company."\n
            Phone: ".$phone."\n
            Address: ".$address."\n
            Sq Ft: ".$squarefeet."\n
            Cleaning Type: ".$cleaningtype."\n\n
            Message: ".$message;

    mail($mailTo, $headers, $txt);
    header("Location: index.html?Success!");
}